create definer = root@localhost view eye_news as
select `hospital`.`news`.`new_id`  AS `new_id`,
       `hospital`.`news`.`title`   AS `title`,
       `hospital`.`news`.`content` AS `content`
from `hospital`.`news`;

-- comment on column eye_news.new_id not supported: 新闻id

-- comment on column eye_news.title not supported: 新闻标题

-- comment on column eye_news.content not supported: 新闻内容

